Nome: Bryan Jonathan
Instruções:
Arquivos pdfs devem ser colocados na pasta /PDFs para processamento.

Para compilação, é necessário ter instalado:
Python: https://www.python.org/downloads/

Após isso, utilizar o comando:
pip install -r requirements.txt

e para a execução em ambiente local:
python app.py
e após isso entrar no link disponibilizado pelo cmd.

Link para aplicação online:
talk.azurewebsites.net